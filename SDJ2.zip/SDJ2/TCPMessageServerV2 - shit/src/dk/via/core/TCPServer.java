package dk.via.core;

import com.google.gson.Gson;
import dk.via.connection.TCPConnection;
import dk.via.connection.TCPConnectionPool;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

import static dk.via.core.TCPConfig.PORT;

public class TCPServer
{
  public static void main(String[] args) throws IOException
  {
    new TCPServer().run();
  }

  private Gson gson = new Gson();

  private void run() throws IOException
  {
    ServerSocket serverSocket = new ServerSocket(PORT);
    System.out.println("Server listening on " + InetAddress.getLocalHost().getHostAddress());

    while (true)
    {
      Socket clientSocket = serverSocket.accept();
      System.out.println("Connected to: " + clientSocket.getInetAddress().getHostAddress());
      new Thread( new ServerThread( clientSocket ) ).start();
    }
  }

  private void work(Socket clientSocket)
      throws IOException
  {
    TCPConnectionPool connectionPool = new TCPConnectionPool();
    TCPConnection connection = new TCPConnection(clientSocket,connectionPool);
    Thread thread = new Thread(connection);
    thread.start();
    connectionPool.addConnection(new TCPConnection(clientSocket,connectionPool));

    ObjectInputStream inputStream = new ObjectInputStream(clientSocket.getInputStream());
    ObjectOutputStream outputStream = new ObjectOutputStream(clientSocket.getOutputStream());





  }

  private class ServerThread implements Runnable
  {
    private Socket clientSocket;

    public ServerThread(Socket clientSocket)
    {
      this.clientSocket = clientSocket;
    }

    public void run()
    {
      try
      {
        work(clientSocket);
      }
      catch (Exception ex)
      {
        ex.printStackTrace();
      }
    }
  }
}