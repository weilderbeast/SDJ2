package dk.via.core;

import com.google.gson.Gson;

import javax.swing.*;
import java.io.IOException;

public class TCPClient
{
  private static int ID;
  private Gson gson;
  private String ip;

  public TCPClient(int id)
  {
    this.ID = id;
  }

  public static void main(String[] args) throws IOException
  {
    new TCPClient(1).run();
  }

  public void run()
  {
    ip = JOptionPane.showInputDialog( null, "IP address" );
    if( ip == null || ip.length() == 0 )
      return;

  }
}
