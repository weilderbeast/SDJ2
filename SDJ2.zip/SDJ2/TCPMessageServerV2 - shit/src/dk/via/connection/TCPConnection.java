package dk.via.connection;

import dk.via.utils.Message;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class TCPConnection implements Runnable
{
  private Socket clientSocket;

  private ObjectOutputStream outputStream;
  private ObjectInputStream inputStream;

  private TCPConnectionPool connectionPool;

  public TCPConnection(Socket connectionSocket, TCPConnectionPool connectionPool)
      throws IOException
  {
    clientSocket = connectionSocket;
    this.connectionPool = connectionPool;

    outputStream = new ObjectOutputStream(clientSocket.getOutputStream());
    inputStream = new ObjectInputStream(clientSocket.getInputStream());
  }

  @Override public void run()
  {
    while(true)
    {
      try
      {
        Message message = (Message) inputStream.readObject();
        System.out.println("Message from client: "+ message);
        connectionPool.broadcast(message);
      }
      catch (Exception e){}
    }
  }

  public void sendToClient(Message message) throws IOException
  {
    outputStream.writeUnshared(message);
  }
}
