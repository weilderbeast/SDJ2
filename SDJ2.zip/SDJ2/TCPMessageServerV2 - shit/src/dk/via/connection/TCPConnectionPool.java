package dk.via.connection;

import dk.via.utils.Message;

import java.io.IOException;
import java.util.ArrayList;

public class TCPConnectionPool
{
  private ArrayList<TCPConnection> connections = new ArrayList<>();

  public TCPConnectionPool()
  {

  }

  public void addConnection(TCPConnection connection)
  {
    connections.add(connection);
  }

  public void broadcast(Message messsage) throws IOException
  {
    System.out.println("Broadcasting to "+ connections.size()+" clients.");
    for (TCPConnection tcp: connections)
    {
      Thread thread = new Thread(tcp);
      thread.start();
      tcp.sendToClient(messsage);
    }
  }
}
