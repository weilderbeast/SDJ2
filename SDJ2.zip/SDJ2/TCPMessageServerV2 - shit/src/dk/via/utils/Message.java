package dk.via.utils;

public class Message
{
  private String messageSender;
  private String messageBody;

  public Message(String messageSender,String messageBody)
  {
    this.messageSender = messageSender;
    this.messageBody = messageBody;
  }

  public String getMessageSender(){
    return messageSender;
  }
  public String getMessageBody() { return messageBody; }

  public String toString(){
    return messageSender + ": " + messageBody + "/n";
  }
}
