package dk.via.sep;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Server
{
  public static void main(String[] args)
      throws IOException, ClassNotFoundException
  {
    ServerSocket serverSocket = new ServerSocket(6969);

    while(true)
    {
      Socket client = serverSocket.accept();
      new Server().run(client);
    }
  }

  public void run(Socket client) throws IOException, ClassNotFoundException
  {

    System.out.println(client.getInetAddress().getHostAddress());

    ObjectOutputStream outToClient = new ObjectOutputStream(client.getOutputStream());
    ObjectInputStream inFromClient = new ObjectInputStream(client.getInputStream());

    while (true)
    {
      outToClient.writeUnshared("Choose your service: ");

      String choice = (String)inFromClient.readObject();
      System.out.println(choice);
      if(choice.equals("VAT"))
      {
        outToClient.writeUnshared("Input the price:");
        double amount = Double.parseDouble(inFromClient.readObject().toString());
        outToClient.writeUnshared("The VAT is: "+amount*0.25);
      }
      else if(choice.equals("Prime"))
      {
        outToClient.writeUnshared("Input the number:");
        boolean a = isPrime(Integer.parseInt(inFromClient.readObject().toString()));
        outToClient.writeUnshared("Prime: "+ a);
      }
      else if(choice.equals("Reverse"))
      {
        outToClient.writeUnshared("Input the string:");
        String a = reverseString(inFromClient.readObject().toString());
        outToClient.writeUnshared("Reverse string: "+ a);
      }
      else if(choice.equals("exit")) break;
    }

    client.close();
  }

  private boolean isPrime(int n)
  {
    if(n <= 1) return false;
    for (int i=2;i<n/2;i++)
    {
      if(n%i==0)
        return false;
    }
    return true;
  }

  private String reverseString(String string)
  {
    String output = "";
    for(int i= string.length()-1;i>=0;i--)
    {
      output += string.charAt(i);
    }
    return output;
  }
}
