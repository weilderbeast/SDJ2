package dk.via.sep;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;

public class Client
{
  public static void main(String[] args)
      throws IOException, ClassNotFoundException
  {
    Socket socket = new Socket("Localhost", 6969);
    Scanner scanner = new Scanner(System.in);
    ObjectInputStream inFromServer = new ObjectInputStream(socket.getInputStream());
    ObjectOutputStream outToServer = new ObjectOutputStream(socket.getOutputStream());

    while (true)
    {
      String messageFromServer = (String) inFromServer.readObject();
      System.out.println(messageFromServer);

      String choice = scanner.nextLine();
      outToServer.writeUnshared(choice);

      messageFromServer = (String) inFromServer.readObject();
      System.out.println(messageFromServer);

      choice = scanner.nextLine();
      outToServer.writeUnshared(choice);

      messageFromServer = (String) inFromServer.readObject();
      System.out.println(messageFromServer);
    }

    //socket.close();
  }
}
