package dk.via.server;

import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class Server
{
  public void start()
  {
    try{
      ServerSocket serverSocket = new ServerSocket(6969);
      ConnectionPool connectionPool = new ConnectionPool();
      System.out.println("Connected to "+ InetAddress.getLocalHost().getHostAddress());

      while(true)
      {
        Socket socket = serverSocket.accept();
        System.out.println("Client connected: " +InetAddress.getLocalHost().getAddress());

        ServerHandler serverHandler = new ServerHandler(socket,connectionPool);
        connectionPool.addConnection(serverHandler);
        Thread server = new Thread(serverHandler);
        server.start();
      }
    }
    catch (Exception e){

    }
  }
}
