package dk.via.server;

import dk.via.utils.Message;

import java.util.ArrayList;

public class ConnectionPool
{
  private ArrayList<ServerHandler> connections = new ArrayList<>();

  public void addConnection(ServerHandler connection)
  {
    connections.add(connection);
  }

  public void broadcast(Message message)
  {
    for (ServerHandler connected: connections)
    {
      //for dms, rewrite message class to contain a target
      //if there's no target send it to anyone, if there is send it to that specific client
      if(!connected.getClient().equals(message.getUser()))
      {
        connected.send(message);
      }
    }
  }

  public void removeConnection(ServerHandler connection)
  {
    connections.remove(connection);
  }
}
