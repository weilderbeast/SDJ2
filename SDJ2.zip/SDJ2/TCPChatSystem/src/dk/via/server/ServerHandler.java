package dk.via.server;

import dk.via.utils.Message;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ServerHandler implements Runnable
{
  private Socket socket;
  private ObjectOutputStream outputStream;
  private ObjectInputStream inputStream;
  private ConnectionPool connectionPool;
  private String username;

  public ServerHandler(Socket socket,ConnectionPool pool)
  {
    this.socket = socket;
    this.connectionPool = pool;

    try{
      inputStream = new ObjectInputStream(socket.getInputStream());
      outputStream = new ObjectOutputStream(socket.getOutputStream());
    }
    catch (Exception e){}
  }

  @Override public void run()
  {
    try{
      username = (String) inputStream.readObject();
      while(true)
      {
        Message message = (Message) inputStream.readObject();

        String body = message.getMessageBody();
        System.out.println(message);

        if(body.equalsIgnoreCase("exit")){
          connectionPool.removeConnection(this);
          socket.close();
          break;
        }

        connectionPool.broadcast(message);
      }
    }
    catch (Exception e){}
  }

  public void send(Message message)
  {
    try
    {
      outputStream.writeObject(message);
    }
    catch (IOException e)
    {
      e.printStackTrace();
    }
  }

  public String getClient() { return username; }
}
