package dk.via.server;

public class StartServer
{
  public static void main(String[] args)
  {
    Server chatServer = new Server();
    chatServer.start();
  }
}
