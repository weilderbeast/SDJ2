package dk.via.client;

import dk.via.utils.Message;

import javax.sound.midi.MetaMessage;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;

public class ChatClient
{
  ObjectInputStream inputStream;

  public void start() throws IOException
  {
    try{
      Socket socket = new Socket("localhost",6969);
      ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
      inputStream = new ObjectInputStream(socket.getInputStream());
      Scanner scanner = new Scanner(System.in);

      Thread thread = new Thread(() -> listenToServer());
      thread.setDaemon(true);
      thread.start();

      System.out.println("Username: ");
      String username = scanner.nextLine();
      outputStream.writeObject(username);

      while (true)
      {
        System.out.println("Message: ");
        String message = scanner.nextLine();
        Message m = new Message(message,username);
        outputStream.writeObject(m);

        if(message.equalsIgnoreCase("exit"))
        {
          socket.close();
          break;
        }
      }
    }
    catch (Exception e){}
  }

  private void listenToServer()
  {
    try{
      while (true)
      {
        Message response = (Message) inputStream.readObject();
        System.out.println(response);
      }
    }
    catch (IOException | ClassNotFoundException e){}
  }
}
