package dk.via.client;

import java.io.IOException;

public class StartChatClient
{
  public static void main(String[] args) throws IOException
  {
    ChatClient client = new ChatClient();
    client.start();
  }
}
