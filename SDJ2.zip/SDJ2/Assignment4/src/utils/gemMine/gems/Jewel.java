package utils.gemMine.gems;

public class Jewel implements Gem {
    @Override
    public String getName() {
        return "jewel";
    }

    @Override
    public int getValue() {
        return 8;
    }
}
