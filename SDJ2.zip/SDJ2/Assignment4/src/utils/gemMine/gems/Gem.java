package utils.gemMine.gems;

public interface Gem {
    String getName();
    int getValue();
}
