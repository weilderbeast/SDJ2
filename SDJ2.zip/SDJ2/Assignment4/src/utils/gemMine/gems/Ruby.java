package utils.gemMine.gems;

public class Ruby implements Gem{
    @Override
    public String getName() {
        return "ruby";
    }

    @Override
    public int getValue() {
        return 12;
    }
}
