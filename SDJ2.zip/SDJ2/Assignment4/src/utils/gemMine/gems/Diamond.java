package utils.gemMine.gems;

public class Diamond implements Gem{
    @Override
    public String getName() {
        return "diamond";
    }

    @Override
    public int getValue() {
        return 10;
    }
}
