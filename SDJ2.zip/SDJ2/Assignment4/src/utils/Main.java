package utils;

import utils.gemMine.deposit.GemDeposit;

public class Main {
    public static void main(String[] args) {
        GemDeposit gemDeposit = new GemDeposit(69);

    }
}
