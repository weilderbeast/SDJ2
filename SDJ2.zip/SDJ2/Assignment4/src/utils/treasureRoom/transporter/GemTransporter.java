package utils.treasureRoom.transporter;

import utils.gemMine.deposit.GemDeposit;
import utils.gemMine.gems.Gem;

import java.util.ArrayList;
import java.util.Random;

public class GemTransporter implements Runnable {
    private Random random = new Random();
    private GemDeposit gemDeposit;
    private ArrayList<Gem> shoppingCart = new ArrayList<>();
    private int totalValue;

    public GemTransporter(GemDeposit gemDeposit) {
        this.gemDeposit = gemDeposit;
        totalValue = 0;
    }

    @Override
    public void run() {
        while (true) {
            int randValue = random.nextInt(151) + 50;
            while (totalValue < randValue) {
                Gem gem = gemDeposit.takeGem();
                shoppingCart.add(gem);
                totalValue += gem.getValue();
            }
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            totalValue = 0;
        }
    }
}
