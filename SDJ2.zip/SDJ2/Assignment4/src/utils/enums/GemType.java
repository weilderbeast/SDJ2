package utils.enums;

public enum GemType {
    DIAMOND,
    RUBY,
    JEWEL,
    COIN
}
