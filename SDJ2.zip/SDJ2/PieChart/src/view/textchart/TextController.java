package view.textchart;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import viewmodel.ViewModelFactory;
import viewmodel.textrepresentation.TextViewModel;

public class TextController
{
  @FXML private Button saveButton;
  @FXML private TextField yTextField;
  @FXML private TextField zTextField;
  @FXML private TextField xTextField;
  @FXML private Label eventLabel;
  private TextViewModel viewModel;


  public void init(TextViewModel vm)
  {
    viewModel = vm;
    xTextField.textProperty().bindBidirectional(vm.xProperty());
    yTextField.textProperty().bindBidirectional(vm.yProperty());
    zTextField.textProperty().bindBidirectional(vm.zProperty());
    eventLabel.textProperty().bind(vm.updateTimeStampProperty());
  }

  public void onUpdateButton(ActionEvent actionEvent)
  {

  }
}
