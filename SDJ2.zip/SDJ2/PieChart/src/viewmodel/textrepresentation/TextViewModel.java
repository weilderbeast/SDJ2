package viewmodel.textrepresentation;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import model.ModelFactory;

public class TextViewModel
{
  private StringProperty x;
  private StringProperty y;
  private StringProperty z;
  private StringProperty updateTimeStamp;
  private ModelFactory model;

  public TextViewModel(ModelFactory model){
    this.model = model;
    x = new SimpleStringProperty();
    y = new SimpleStringProperty();
    z = new SimpleStringProperty();
    updateTimeStamp = new SimpleStringProperty();
  }

  public void updateTextFields()
  {

  }

  public StringProperty xProperty()
  {
    return x;
  }

  public StringProperty yProperty()
  {
    return y;
  }

  public StringProperty zProperty()
  {
    return z;
  }

  public StringProperty updateTimeStampProperty()
  {
    return updateTimeStamp;
  }
}
