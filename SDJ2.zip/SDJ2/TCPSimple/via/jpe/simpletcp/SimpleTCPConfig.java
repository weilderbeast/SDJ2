/*
 * 08.09.2019 package name updated
 * 28.02.2011 Original version
 */
 
 
package via.jpe.simpletcp;


public class SimpleTCPConfig
{
	public static final int PORTNO = 4711;
}