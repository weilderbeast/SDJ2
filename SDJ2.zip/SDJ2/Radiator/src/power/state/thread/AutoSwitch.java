package power.state.thread;

import core.Radiator;
import power.state.Power3State;

public class AutoSwitch implements Runnable
{
  private Radiator radiator;
  public AutoSwitch(Radiator radiator)
  {
    this.radiator=radiator;
  }
  @Override public void run()
  {
      try
      {
        //this is interrupted so it skips directly to the catch clause
        Thread.sleep(5000);
        System.out.println("automatically turned down the power to 2");
        radiator.turnDown();
      }
      catch (InterruptedException e)
      {

      }
  }
}
