package power.state;

import core.Radiator;
import power.state.thread.AutoSwitch;

public class Power3State implements RadiatorState
{
  private int power=3;
  private Thread thread;

  public Power3State(Radiator radiator)
  {
    AutoSwitch autoSwitch = new AutoSwitch(radiator);
    Thread thread = new Thread(autoSwitch);
    this.thread=thread;
    thread.start();
  }

  @Override public void turnUp(Radiator radiator)
  {
    //do nothing
  }

  @Override public void turnDown(Radiator radiator)
  {
    System.out.println("Turned the radiator down.");
    thread.interrupt();
    radiator.setCurrentState(new Power2State());
    getPower(radiator);
  }

  @Override public void getPower(Radiator radiator)
  {
    radiator.setPower(power);
  }
}
