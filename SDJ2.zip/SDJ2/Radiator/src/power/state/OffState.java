package power.state;

import core.Radiator;

public class OffState implements RadiatorState
{
  private int power=0;
  @Override public void turnUp(Radiator radiator)
  {
    System.out.println("Turned the radiator up.");
    radiator.setCurrentState(new Power1State());
    getPower(radiator);
  }

  @Override public void turnDown(Radiator radiator)
  {
    //do nothing
  }

  @Override public void getPower(Radiator radiator)
  {
    radiator.setPower(power);
  }
}
