package power.state;

import core.Radiator;

public class Power1State implements RadiatorState
{
  private int power=1;
  @Override public void turnUp(Radiator radiator)
  {
    System.out.println("Turned the radiator up.");
    radiator.setCurrentState(new Power2State());
    getPower(radiator);
  }

  @Override public void turnDown(Radiator radiator)
  {
    System.out.println("Turned the radiator down.");
    radiator.setCurrentState(new OffState());
    getPower(radiator);
  }

  @Override public void getPower(Radiator radiator)
  {
    radiator.setPower(power);
  }
}
