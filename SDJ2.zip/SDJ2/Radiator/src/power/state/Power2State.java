package power.state;

import core.Radiator;

public class Power2State implements RadiatorState
{
  private int power=2;
  @Override public void turnUp(Radiator radiator)
  {
    System.out.println("Turned the radiator up.");
    radiator.setCurrentState(new Power3State(radiator));
    getPower(radiator);
  }

  @Override public void turnDown(Radiator radiator)
  {
    System.out.println("Turned the radiator down.");
    radiator.setCurrentState(new Power1State());
    getPower(radiator);
  }

  @Override public void getPower(Radiator radiator)
  {
    radiator.setPower(power);
  }
}
