import core.Radiator;

public class Main
{
  public static void main(String[] args)
  {
    Radiator radiator = new Radiator();
    System.out.println(radiator);
    radiator.turnUp();
    System.out.println(radiator);
    radiator.turnUp();
    radiator.turnUp();


  }
}
