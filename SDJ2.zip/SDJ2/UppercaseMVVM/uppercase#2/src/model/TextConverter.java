package model;

public interface TextConverter
{
  String toUppercase(String string);
}
