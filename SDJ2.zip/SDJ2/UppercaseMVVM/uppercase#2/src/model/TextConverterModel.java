package model;

import org.w3c.dom.Text;

public class TextConverterModel implements TextConverter
{
  @Override public String toUppercase(String string)
  {
    return string.toUpperCase();
  }
}
