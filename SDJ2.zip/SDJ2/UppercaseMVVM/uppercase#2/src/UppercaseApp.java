import core.ModelFactory;
import core.ViewHandler;
import core.ViewModelFactory;
import javafx.stage.Stage;

public class UppercaseApp extends javafx.application.Application
{
  @Override public void start(Stage stage) throws Exception
  {
    ModelFactory mf = new ModelFactory();
    ViewModelFactory vmf = new ViewModelFactory(mf);
    ViewHandler vh = new ViewHandler(vmf);

    vh.start();
  }
}
