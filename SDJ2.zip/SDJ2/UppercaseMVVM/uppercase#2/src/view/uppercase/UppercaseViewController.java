package view.uppercase;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class UppercaseViewController
{
  @FXML private TextField request;
  @FXML private TextField result;
  @FXML private Button submit;
  @FXML private Label error;
  private UppercaseViewModel viewModel;

  public void generate(javafx.event.ActionEvent actionEvent)
  {
    viewModel.convert();
  }

  public void init(UppercaseViewModel uppercaseViewModel)
  {
    result.setDisable(true);
    this.viewModel=uppercaseViewModel;
    error.textProperty().bind(viewModel.errorProperty());
    request.textProperty().bindBidirectional(viewModel.requestProperty());
    result.textProperty().bind(viewModel.replyProperty());

  }
}
