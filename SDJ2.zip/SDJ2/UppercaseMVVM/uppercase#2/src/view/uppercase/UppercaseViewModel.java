package view.uppercase;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import model.TextConverter;

public class UppercaseViewModel
{
  private TextConverter textConverter;
  private StringProperty request;
  private StringProperty reply;
  private StringProperty error;

  public UppercaseViewModel(TextConverter textConverter)
  {
    request = new SimpleStringProperty();
    reply = new SimpleStringProperty();
    error = new SimpleStringProperty();
    this.textConverter = textConverter;
  }

  public void convert()
  {
    String input = request.get();
    if(input != null && !"".equalsIgnoreCase(input))
    {
      String result = textConverter.toUppercase(input);
      reply.set(result);
    }
    else{
      error.set("Input cannot be empty");
    }
  }

  public String getRequest()
  {
    return request.get();
  }

  public StringProperty requestProperty()
  {
    return request;
  }

  public String getReply()
  {
    return reply.get();
  }

  public StringProperty replyProperty()
  {
    return reply;
  }

  public String getError()
  {
    return error.get();
  }

  public StringProperty errorProperty()
  {
    return error;
  }
}
