# UppercaseMVVM

A super simple example, mainly to display the MVVM structure. It's just a GUI, where you can insert a text, click a button, and see that text as upper case.
The example covers our basic MVVM structure, bindings between view and controller, and access to a model.
