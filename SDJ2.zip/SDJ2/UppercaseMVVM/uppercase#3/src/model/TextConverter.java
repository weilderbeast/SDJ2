package model;

import java.util.List;

public interface TextConverter
{
  String toUppercase(String string);
  void addLog(String log);
  List<String> getLogs();
  int getLogLenght();
}
