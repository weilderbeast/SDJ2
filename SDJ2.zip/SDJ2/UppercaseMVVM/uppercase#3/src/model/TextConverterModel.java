package model;

import javafx.collections.ObservableList;
import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

public class TextConverterModel implements TextConverter
{

  private ArrayList<String> list;

  public TextConverterModel(){
    list = new ArrayList<>();
  }

  @Override public String toUppercase(String string)
  {
    addLog(string);
    return string.toUpperCase();
  }

  @Override public void addLog(String log)
  {
    list.add(log);
  }

  @Override public List<String> getLogs()
  {
    return this.list;
  }

  @Override public int getLogLenght()
  {
    return list.size();
  }
}
