package view.uppercase.log;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.TextConverter;

public class  LogViewModel
{
  private TextConverter textConverter;
  ObservableList<String> logs;

  public LogViewModel(TextConverter textConverter)
  {
    this.textConverter=textConverter;
    logs = FXCollections.observableArrayList();
  }

  public ObservableList<String> getLogs()
  {
    return logs;
  }

  public void updateLogs()
  {
    logs.clear();
    logs.addAll(textConverter.getLogs());
  }
}
