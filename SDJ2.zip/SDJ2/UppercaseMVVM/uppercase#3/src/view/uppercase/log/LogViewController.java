package view.uppercase.log;

import core.ViewHandler;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;

public class LogViewController
{

  @FXML private Button backButton;
  @FXML private ListView<String> logList;
  private LogViewModel logViewModel;
  private ViewHandler viewHandler;

  public void init(ViewHandler viewHandler, LogViewModel logViewModel)
  {
    this.viewHandler=viewHandler;
    this.logViewModel=logViewModel;
    logViewModel.updateLogs();
    logList.setItems(logViewModel.getLogs());
  }

  public void goBack(ActionEvent actionEvent)
  {
    viewHandler.openToUpperCase();
  }
}
