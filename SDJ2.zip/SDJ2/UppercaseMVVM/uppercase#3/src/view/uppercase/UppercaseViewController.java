package view.uppercase;

import core.ViewHandler;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class UppercaseViewController
{
  @FXML private Button logButton;
  @FXML private TextField request;
  @FXML private TextField result;
  @FXML private Button submit;
  @FXML private Label error;
  private UppercaseViewModel viewModel;
  private ViewHandler viewHandler;

  public void generate(javafx.event.ActionEvent actionEvent)
  {
    viewModel.convert();
  }

  public void init(UppercaseViewModel uppercaseViewModel, ViewHandler viewHandler)
  {
    result.setDisable(true);
    this.viewModel=uppercaseViewModel;
    this.viewHandler=viewHandler;
    viewModel.clear();
    error.textProperty().bind(viewModel.errorProperty());
    request.textProperty().bindBidirectional(viewModel.requestProperty());
    result.textProperty().bind(viewModel.replyProperty());
  }

  public void openLogs(ActionEvent actionEvent)
  {
    viewHandler.openLogView();
  }

}
