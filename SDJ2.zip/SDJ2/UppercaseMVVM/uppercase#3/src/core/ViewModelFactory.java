package core;

import view.uppercase.log.LogViewModel;
import view.uppercase.UppercaseViewModel;

public class ViewModelFactory
{
  private UppercaseViewModel uppercaseViewModel;
  private ModelFactory mf;
  private LogViewModel logViewModel;
  public ViewModelFactory(ModelFactory mf)
  {
    this.mf = mf;
    uppercaseViewModel = new UppercaseViewModel(mf.getTextConverter());
    logViewModel = new LogViewModel(mf.getTextConverter());
  }

  public UppercaseViewModel getUppercaseViewModel()
  {
    return uppercaseViewModel;
  }

  public LogViewModel getLogViewModel()
  {
    return logViewModel;
  }
}
