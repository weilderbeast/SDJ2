package uppercase;

import javafx.application.Application;

public class RunUppercaseApp {

    public static void main(String[] args) {
        Application.launch(UppercaseApp.class);
    }
}
