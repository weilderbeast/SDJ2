package uppercase.model;

public interface TextConverter {

    String toUppercase(String text);

}


