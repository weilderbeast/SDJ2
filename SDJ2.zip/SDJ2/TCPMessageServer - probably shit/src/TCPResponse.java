public class TCPResponse
{
}
