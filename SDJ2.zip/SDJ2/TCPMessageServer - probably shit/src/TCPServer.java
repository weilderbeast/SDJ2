import com.google.gson.Gson;

import java.io.IOException;
import java.net.ServerSocket;
import

public class TCPServer
{
  public static void main(String[] args)
  {

  }

  private Gson gson = new Gson();

  public void run() throws IOException
  {
    ServerSocket serverSocket = new ServerSocket(PORT);
  }
}
