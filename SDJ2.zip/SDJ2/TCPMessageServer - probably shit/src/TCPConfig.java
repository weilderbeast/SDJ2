public class TCPConfig
{
  public static final int PORT = 6969;
}
