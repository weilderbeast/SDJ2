public class TCPRequest
{
}
