package datavisualizerwithobserver;

import javafx.application.Application;

public class RunDataVisualizer {

    public static void main(String[] args) throws Exception {
        Application.launch(DatavisualizerApp.class);
    }
}
