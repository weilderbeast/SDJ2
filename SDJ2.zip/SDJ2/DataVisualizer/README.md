# DataVisualizer
A simple example which displays three double values in different windows, in different ways.
Using our JavaFX-MVVM approach, with the ViewModels observing the Model.
Charts: Bar and Pie.
