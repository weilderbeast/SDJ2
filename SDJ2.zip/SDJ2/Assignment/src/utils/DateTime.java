package utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateTime
{
  private Date date;

  public DateTime()
  {
    date = Calendar.getInstance().getTime();
  }
  public String getTimestamp()
  {
    SimpleDateFormat sdf = new SimpleDateFormat(
        "HH:mm:ss");
    return sdf.format(date);
  }
}
