package view.temperature;

import core.ViewHandler;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;

import java.io.IOException;

public class TemperatureViewController
{
  @FXML private Label temp1;
  @FXML private Label temp2;
  @FXML private Label temp3;
  @FXML private Label radiatorPower;
  @FXML private Label criticalLabel;

  private TemperatureViewModel temperatureViewModel;
  private ViewHandler viewHandler;

  public void init(TemperatureViewModel temperatureViewModel,ViewHandler viewHandler)
  {
    this.temperatureViewModel = temperatureViewModel;
    this.viewHandler = viewHandler;

    temp1.textProperty().bind(temperatureViewModel.getT1());
    temp2.textProperty().bind(temperatureViewModel.getT2());
    temp3.textProperty().bind(temperatureViewModel.getT3());

    radiatorPower.textProperty().bind(temperatureViewModel.getRadiatorPower());

    criticalLabel.textProperty().addListener(new ChangeListener<String>()
    {
      @Override public void changed(
          ObservableValue<? extends String> observableValue, String s,
          String t1)
      {
        if(t1 == null) return;
        if(t1.equals("low"))
          criticalLabel.setTextFill(Color.web("#0000FF"));
          else if(t1.equals("normal")) criticalLabel.setTextFill(Color.web("#00FF00"));
            else criticalLabel.setTextFill(Color.web("#FF0000"));
      }
    });
    criticalLabel.textProperty().bind(temperatureViewModel.getCriticalTemperature());
  }

  public void openLogs(ActionEvent actionEvent) throws IOException
  { viewHandler.openView("LogView");}

  public void turnRadiatorUp(ActionEvent actionEvent)
  {
    temperatureViewModel.turnRadiatorUp();
  }
  public void turnRadiatorDown(ActionEvent actionEvent)
  {
    temperatureViewModel.turnRadiatorDown();
  }

}
