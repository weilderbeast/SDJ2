package view.temperature;

import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import model.Model;

import java.beans.PropertyChangeEvent;
import java.text.DecimalFormat;

public class TemperatureViewModel
{
  private StringProperty t1;
  private StringProperty t2;
  private StringProperty t3;
  private StringProperty criticalTemperature;

  private StringProperty radiatorPower;

  private Model model;

  public TemperatureViewModel(Model model)
  {
    this.model = model;

    t1 = new SimpleStringProperty();
    t2 = new SimpleStringProperty();
    t3 = new SimpleStringProperty();

    radiatorPower = new SimpleStringProperty();

    criticalTemperature = new SimpleStringProperty();

    model.addListener("Data", evt -> updateTemps(evt));
    model.addListener("Power", evt -> updateRad(evt));
    model.addListener("Critical", evt -> updateCritical(evt));
  }

  public void updateTemps(PropertyChangeEvent evt)
  {
    Platform.runLater(
        () -> {
          double[] temps = (double[]) evt.getNewValue();
          DecimalFormat df = new DecimalFormat("#.###");

          t1.setValue("" + df.format(temps[0]));
          t2.setValue("" + df.format(temps[1]));
          t3.setValue("" + df.format(temps[2]));
        }
    );
  }

  public void updateRad(PropertyChangeEvent evt)
  {
    Platform.runLater(
        () -> {
          int temp = (int) evt.getNewValue();
          radiatorPower.setValue(String.valueOf(temp));
        }
    );
  }

  public void updateCritical(PropertyChangeEvent evt)
  {
    Platform.runLater(
        () -> {
          String temp = (String) evt.getNewValue();
          criticalTemperature.setValue(temp);
        }
    );
  }
  public StringProperty getT1() { return t1; }
  public StringProperty getT2() { return t2; }
  public StringProperty getT3() { return t3; }
  public StringProperty getRadiatorPower() { return radiatorPower; }
  public StringProperty getCriticalTemperature() { return criticalTemperature; }

  public void turnRadiatorUp(){ model.turnRadiatorUp(); }
  public void turnRadiatorDown(){ model.turnRadiatorDown(); }

}
