package view.log;

import javafx.application.Platform;
import javafx.scene.chart.XYChart;
import model.Model;
import utils.DateTime;

import java.beans.PropertyChangeEvent;
import java.text.DecimalFormat;

public class LogViewModel
{
  private Model logModel;

  private XYChart.Series t1series = new XYChart.Series();
  private XYChart.Series t2series = new XYChart.Series();
  private XYChart.Series t3series = new XYChart.Series();

  public LogViewModel(Model logModel)
  {
    this.logModel = logModel;

    this.logModel.addListener("ChartData", evt -> updateChart(evt));

    t1series.setName("t1");
    t2series.setName("t2");
    t3series.setName("outside");
  }

  public void updateChart(PropertyChangeEvent evt)
  {
    Platform.runLater(
        () -> {
          double[] temps = (double[]) evt.getNewValue();
          DecimalFormat df = new DecimalFormat("#.###");

          DateTime dateTime = new DateTime();

          if(temps[0] > 0)
          t1series.getData().add(new XYChart.Data(dateTime.getTimestamp(),Double.parseDouble(df.format(temps[0]))));

          if(temps[1] > 0)
          t2series.getData().add(new XYChart.Data(dateTime.getTimestamp(),Double.parseDouble(df.format(temps[1]))));

          if(temps[2] > 0)
          t3series.getData().add(new XYChart.Data(dateTime.getTimestamp(),Double.parseDouble(df.format(temps[2]))));
        }
    );
  }

  public XYChart.Series getT1series() { return t1series; }
  public XYChart.Series getT2series() { return t2series; }
  public XYChart.Series getT3series() { return t3series; }

}
