package view.log;

import core.ViewHandler;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;

import java.io.IOException;

public class LogViewController
{
  @FXML private LineChart lineChart;

  private ViewHandler viewHandler;
  private LogViewModel logViewModel;

  public void init(LogViewModel logViewModel,ViewHandler viewHandler)
  {
    this.logViewModel = logViewModel;
    this.viewHandler = viewHandler;

    NumberAxis xAxis = new NumberAxis();
    NumberAxis yAxis = new NumberAxis();
    xAxis.setLabel("Time");
    yAxis.setLabel("Temperature");
    yAxis.setAutoRanging(true);

    lineChart.setTitle("Temperatures");

    lineChart.getData().add(this.logViewModel.getT1series());
    lineChart.getData().add(this.logViewModel.getT2series());
    lineChart.getData().add(this.logViewModel.getT3series());
  }

  public void openTempView(ActionEvent actionEvent) throws IOException
  {viewHandler.openView("TemperatureView");}

}
