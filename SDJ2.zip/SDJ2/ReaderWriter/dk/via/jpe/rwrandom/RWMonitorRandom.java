/*
 * 04.11.2019 Original version
 */


package dk.via.jpe.rwrandom;


import dk.via.jpe.rw.RWMonitor;


public class RWMonitorRandom
	implements RWMonitor
{
	private int noReaders = 0;
	private int noWriters = 0;
	

	@Override
	public synchronized void acquireRead()
	{
		while( noWriters > 0 )
			try {
				wait();
			} catch( InterruptedException ex ) {
			}
		
		++noReaders;
	}
	
	
	@Override
	public synchronized void releaseRead()
	{
		noReaders--;
		notifyAll();
	}
	
	
	@Override
	public synchronized void acquireWrite()
	{
		while( noWriters > 0 || noReaders > 0 )
			try {
				wait();
			} catch( InterruptedException ex ) {
			}
		++noWriters;
	}
	
	
	@Override
	public synchronized void releaseWrite()
	{
		noWriters--;
		notifyAll();
	}
}
