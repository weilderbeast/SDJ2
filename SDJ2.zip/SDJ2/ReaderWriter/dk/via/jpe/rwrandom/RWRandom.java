/*
 * 04.11.2019 Original version
 */


package dk.via.jpe.rwrandom;


import dk.via.jpe.rw.RWTestMonitor;


public class RWRandom
{
	public static void main( String[] args )
	{
		new RWTestMonitor( new RWMonitorRandom() ).run();
	}
}
