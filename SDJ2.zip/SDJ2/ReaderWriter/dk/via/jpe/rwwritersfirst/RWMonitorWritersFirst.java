/*
 * 04.11.2019 Original version
 */


package dk.via.jpe.rwwritersfirst;


import dk.via.jpe.rw.RWMonitor;


public class RWMonitorWritersFirst
	implements RWMonitor
{
	private int noReaders = 0;
	private int noWriters = 0;
	private int noWritersWaiting = 0;
	

	@Override
	public synchronized void acquireRead()
	{
		while( noWriters > 0 || noWritersWaiting > 0 )
			try {
				wait();
			} catch( InterruptedException ex ) {
			}
		
		++noReaders;
	}
	
	
	@Override
	public synchronized void releaseRead()
	{
		noReaders--;
		notifyAll();
	}
	
	
	@Override
	public synchronized void acquireWrite()
	{
		++noWritersWaiting;
		
		while( noWriters > 0 || noReaders > 0 )
			try {
				wait();
			} catch( InterruptedException ex ) {
			}
		
		noWritersWaiting--;
		++noWriters;
	}
	
	
	@Override
	public synchronized void releaseWrite()
	{
		noWriters--;
		notifyAll();
	}
}
