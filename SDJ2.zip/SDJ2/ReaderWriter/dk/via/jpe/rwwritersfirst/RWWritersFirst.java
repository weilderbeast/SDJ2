/*
 * 04.11.2019 Original version
 */


package dk.via.jpe.rwwritersfirst;


import dk.via.jpe.rw.RWTestMonitor;


public class RWWritersFirst
{
	public static void main( String[] args )
	{
		new RWTestMonitor( new RWMonitorWritersFirst() ).run();
	}
}
