/*
 * 04.11.2019 Original version
 */


package dk.via.jpe.rwreadersfirst;


import dk.via.jpe.rw.RWTestMonitor;


public class RWReadersFirst
{
	public static void main( String[] args )
	{
		new RWTestMonitor( new RWMonitorReadersFirst() ).run();
	}
}
