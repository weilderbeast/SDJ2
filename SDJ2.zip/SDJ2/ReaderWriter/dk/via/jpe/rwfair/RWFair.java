/*
 * 17.11.2019 Original version
 */


package dk.via.jpe.rwfair;


import dk.via.jpe.rw.RWTestMonitor;


public class RWFair
{
	public static void main( String[] args )
	{
		new RWTestMonitor( new RWMonitorFair() ).run();
	}
}
