/*
 * 17.11.2019 Original version
 */

// This version follows the basic rules as in RWMonitorRandom
// but ensures fairness using a "bakery queue"


package dk.via.jpe.rwfair;


import dk.via.jpe.rw.RWMonitor;


public class RWMonitorFair
	implements RWMonitor
{
	private int noReaders = 0;
	private int noWriters = 0;
	
	private int nextTicket = 0; // The "number machine"
	private int nextServed = 0; // The "display"
	

	@Override
	public synchronized void acquireRead()
	{
		int ticket = nextTicket++;
		
		while( ticket != nextServed || noWriters > 0 )
			try {
				wait();
			} catch( InterruptedException ex ) {
			}
		
		++noReaders;
		++nextServed;
		notifyAll(); // If the next one in the queue is a reader it needs a notify
	}
	
	
	@Override
	public synchronized void releaseRead()
	{
		noReaders--;
		notifyAll();
	}
	
	
	@Override
	public synchronized void acquireWrite()
	{
		int ticket = nextTicket++;
		
		while( ticket != nextServed || noWriters > 0 || noReaders > 0 )
			try {
				wait();
			} catch( InterruptedException ex ) {
			}
		
		++noWriters;
		++nextServed;
	}
	
	
	@Override
	public synchronized void releaseWrite()
	{
		noWriters--;
		notifyAll();
	}
}
