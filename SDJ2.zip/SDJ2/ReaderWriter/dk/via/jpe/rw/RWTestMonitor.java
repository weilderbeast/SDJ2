/*
 * 05.11.2020 Runnable
 * 04.11.2019 Original version
 */


package dk.via.jpe.rw;


public class RWTestMonitor
{
	private static final int NO_OF_READERS = 5;
	private static final int NO_OF_WRITERS = 2;
	
	
	private SharedResource resource = new SharedResource();
	private RWMonitor monitor;
	
	
	public RWTestMonitor( RWMonitor monitor )
	{
		this.monitor = monitor;
	}
	
	
	public void run()
	{
		for( int i = 1; i <= NO_OF_READERS; ++i )
			new Thread( new Reader( i, monitor, resource ) ).start();
		
		for( int i = 1; i <= NO_OF_WRITERS; ++i )
			new Thread( new Writer( i, monitor, resource ) ).start();
	}
}
