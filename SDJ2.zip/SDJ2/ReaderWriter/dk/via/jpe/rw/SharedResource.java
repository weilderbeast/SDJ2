/*
 * 04.11.2019 Original version
 */


package dk.via.jpe.rw;


public class SharedResource
{
	private int value;
	
	
	public int getValue()
	{
		return value;
	}
	
	
	public void updateValue()
	{
		++value;
	}
}
