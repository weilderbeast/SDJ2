/*
 * 05.11.2020 Runnable
 * 04.11.2019 Original version
 */


package dk.via.jpe.rw;


import java.util.Random;


public class Reader
	implements Runnable
{
	private static final int MAX_WAIT_TIME = 10000;
	private static final int MAX_WORK_TIME = 5000;
	
	
	private static final Random random = new Random();
	
	private int no;
	private RWMonitor monitor;
	private SharedResource resource;
	
	
	public Reader( int no, RWMonitor monitor, SharedResource resource )
	{
		this.no = no;
		this.monitor = monitor;
		this.resource = resource;
	}
	
	
	public void run()
	{
		while( true ) {
			try {
				Thread.sleep( random.nextInt( MAX_WAIT_TIME ) );
			} catch( InterruptedException ex ) {
			}
			
			System.out.println( "Reader #" + no + " trying to read" );
			
			monitor.acquireRead();
			
			System.out.println( "Reader #" + no + " got read access" );
			
			try {
				Thread.sleep( random.nextInt( MAX_WORK_TIME ) );
			} catch( InterruptedException ex ) {
			}
			
			System.out.println( "Reader #" + no + " read " + resource.getValue() );
			
			monitor.releaseRead();
		}
	}
}
