/*
 * 05.11.2020 Runnable
 * 04.11.2019 Original version
 */


package dk.via.jpe.rw;


import java.util.Random;


public class Writer
	implements Runnable
{
	private static final int MAX_WAIT_TIME = 20000;
	private static final int MAX_WORK_TIME = 10000;
	
	
	private static final Random random = new Random();
	
	private int no;
	private RWMonitor monitor;
	private SharedResource resource;
	
	
	public Writer( int no, RWMonitor monitor, SharedResource resource )
	{
		this.no = no;
		this.monitor = monitor;
		this.resource = resource;
	}
	
	
	public void run()
	{
		while( true ) {
			try {
				Thread.sleep( random.nextInt( MAX_WAIT_TIME ) );
			} catch( InterruptedException ex ) {
			}
			
			System.out.println( "Writer #" + no + " trying to update" );
			
			monitor.acquireWrite();
			
			System.out.println( "Writer #" + no + " got write access" );
			
			try {
				Thread.sleep( random.nextInt( MAX_WORK_TIME ) );
			} catch( InterruptedException ex ) {
			}
			
			resource.updateValue();
			
			System.out.println( "Writer #" + no + " updated" );
			
			monitor.releaseWrite();
		}
	}
}
