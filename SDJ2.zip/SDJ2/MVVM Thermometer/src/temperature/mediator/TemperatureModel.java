package temperature.mediator;

import temperature.model.Temperature;

import java.beans.PropertyChangeListener;
import java.util.ArrayList;

public interface TemperatureModel
{
  void addTemperature(String id, double temperature);
  Temperature getLastInsertedTemperature();
  Temperature getLastInsertedTemperature(String id);
  ArrayList<Temperature> getLastThree();
  void addListener(String name, PropertyChangeListener listener);
}
