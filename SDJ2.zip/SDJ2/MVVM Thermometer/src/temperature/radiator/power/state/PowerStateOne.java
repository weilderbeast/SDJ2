package radiator.power.state;

import radiator.Radiator;

public class PowerStateOne implements RadiatorState
{
  private static final int power = 1;
  @Override public void turnUp(Radiator radiator)
  {
    System.out.println("Turned the radiator up to 2.");
    radiator.setCurrentState(new PowerStateTwo());
  }

  @Override public void turnDown(Radiator radiator)
  {
    System.out.println("Turned the radiator off.");
    radiator.setCurrentState(new OffState());
  }

  @Override public void getPower(Radiator radiator)
  {
    radiator.setPower(power);
  }
}
