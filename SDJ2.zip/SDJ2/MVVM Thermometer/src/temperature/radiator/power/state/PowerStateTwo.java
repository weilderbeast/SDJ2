package radiator.power.state;

import radiator.Radiator;

public class PowerStateTwo implements RadiatorState
{
  private static final int power = 2;
  @Override public void turnUp(Radiator radiator)
  {
    System.out.println("Turned the radiator up to 3.");
    radiator.setCurrentState(new PowerStateThree(radiator));
  }

  @Override public void turnDown(Radiator radiator)
  {
    System.out.println("Turned the radiator down to 1.");
    radiator.setCurrentState(new PowerStateOne());
  }

  @Override public void getPower(Radiator radiator)
  {
    radiator.setPower(power);
  }
}
