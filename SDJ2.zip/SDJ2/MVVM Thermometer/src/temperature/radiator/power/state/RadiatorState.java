package radiator.power.state;

import radiator.Radiator;

public interface RadiatorState
{
  void turnUp(Radiator radiator);
  void turnDown(Radiator radiator);
  void getPower(Radiator radiator);
}
