package radiator.power.state;

import radiator.Radiator;

public class OffState implements RadiatorState
{
  private static final int power = 0;
  @Override public void turnUp(Radiator radiator)
  {
    System.out.println("Turned the radiator up to 1.");
    radiator.setCurrentState(new PowerStateOne());
  }

  @Override public void turnDown(Radiator radiator)
  {
    // do nothing
  }

  @Override public void getPower(Radiator radiator)
  {
    radiator.setPower(power);
  }
}
