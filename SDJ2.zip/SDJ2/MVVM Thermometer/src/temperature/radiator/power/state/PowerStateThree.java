package radiator.power.state;

import radiator.Radiator;
import radiator.power.thread.RadiatorThread;

public class PowerStateThree implements RadiatorState
{
  private static final int power = 3;
  private Thread thread;

  public PowerStateThree(Radiator radiator)
  {
    RadiatorThread radiatorThread = new RadiatorThread(radiator);
    Thread thread = new Thread(radiatorThread);
    this.thread = thread;
    thread.start();
  }

  @Override public void turnUp(Radiator radiator)
  {
    // do nothing.
  }

  @Override public void turnDown(Radiator radiator)
  {
    System.out.println("Turned the radiator down to 2.");
    thread.interrupt();
    radiator.setCurrentState(new PowerStateTwo());
  }

  @Override public void getPower(Radiator radiator)
  {
    radiator.setPower(power);
  }
}
