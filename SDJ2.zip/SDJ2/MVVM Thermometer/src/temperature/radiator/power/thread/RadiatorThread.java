package radiator.power.thread;

import radiator.Radiator;

public class RadiatorThread implements Runnable
{
  private Radiator radiator;
  public RadiatorThread(Radiator radiator)
  {
    this.radiator=radiator;
  }
  @Override public void run()
  {
    try
    {
      //this is interrupted so it skips directly to the catch clause
      Thread.sleep(5000);
      System.out.println("automatically turned down the power to 2");
      radiator.turnDown();
    }
    catch (InterruptedException e) {}
  }
}
