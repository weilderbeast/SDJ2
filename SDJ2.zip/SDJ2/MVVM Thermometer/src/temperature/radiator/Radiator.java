package radiator;

import radiator.power.state.OffState;
import radiator.power.state.RadiatorState;

public class Radiator
{
  private RadiatorState currentState;
  private int power=0;

  public Radiator()
  {
    currentState = new OffState();
  }

  public void turnUp()
  {
    currentState.turnUp(this);
  }
  public void turnDown()
  {
    currentState.turnDown(this);
  }
  public void getPower()
  {
    currentState.getPower(this);
  }
  public void setCurrentState(RadiatorState state)
  {
    currentState = state;
  }
  public void setPower(int power)
  {
    this.power = power;
  }
  public String toString()
  {
    return "Current power: "+power;
  }
}
