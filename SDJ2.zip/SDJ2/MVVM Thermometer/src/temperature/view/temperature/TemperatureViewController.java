package temperature.view.temperature;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Region;
import temperature.core.ViewHandler;
import temperature.model.Temperature;

public class TemperatureViewController
{
   @FXML private Label outputLabel;
   @FXML private Label outputLabel2;
   @FXML private Label outputLabel3;
   @FXML private TextField filterField;
   @FXML private Label filterLabel;

   private ViewHandler viewHandler; //<- why do i need this? what do i use it for?
   private TemperatureViewModel temperatureViewModel;

   private Region root;
   private String thermometerId;

   public TemperatureViewController()
   {
   }

   public void init(ViewHandler viewHandler,TemperatureViewModel temperatureViewModel, Region root)
   {
      this.viewHandler = viewHandler;
      this.temperatureViewModel = temperatureViewModel;

      outputLabel.textProperty().bind(temperatureViewModel.getTemperature().asString());
      outputLabel2.textProperty().bind(temperatureViewModel.getTemperature2().asString());
      outputLabel3.textProperty().bind(temperatureViewModel.getTemperature3().asString());
      //where do i call this?
      //temperatureViewModel.getLastTemp();

      this.root = root;
      thermometerId = null;
   }

   public void reset()
   {
      // empty
   }

   public Region getRoot()
   {
      return root;
   }


}
