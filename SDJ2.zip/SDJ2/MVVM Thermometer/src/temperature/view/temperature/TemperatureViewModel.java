package temperature.view.temperature;

import javafx.application.Platform;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import temperature.mediator.TemperatureModel;
import temperature.model.Temperature;

import java.beans.PropertyChangeEvent;
import java.util.ArrayList;

public class TemperatureViewModel
{
  private DoubleProperty temperature;
  private DoubleProperty temperature2;
  private DoubleProperty temperature3;
  private StringProperty id;
  private TemperatureModel temperatureModel;

  public TemperatureViewModel(TemperatureModel temperatureModel)
  {
    this.temperatureModel = temperatureModel;
    temperature = new SimpleDoubleProperty();
    temperature2 = new SimpleDoubleProperty();
    temperature3 = new SimpleDoubleProperty();
    id = new SimpleStringProperty();

    temperatureModel.addListener("Data", evt -> updateData(evt));
  }

  public void getLastTemp()
  {
    temperature.setValue(temperatureModel.getLastInsertedTemperature(id.getValue()).getValue());
    ArrayList<Temperature> temp = temperatureModel.getLastThree();
    temperature.setValue(temp.get(0).getValue());
    temperature2.setValue(temp.get(1).getValue());
    temperature3.setValue(temp.get(2).getValue());
  }

  public void updateData(PropertyChangeEvent evt)
  {
    Platform.runLater(() -> {
      Temperature value = (Temperature)evt.getNewValue();
      temperature.setValue(value.getValue());
      value = (Temperature)evt.getNewValue();
      temperature2.setValue(value.getValue());
      value = (Temperature)evt.getNewValue();
      temperature3.setValue(value.getValue());
    });  }

  public StringProperty getId()
  {
    return id;
  }

  public DoubleProperty getTemperature()
  {
    return temperature;
  }
  public DoubleProperty getTemperature2() { return temperature2;}
  public DoubleProperty getTemperature3() { return temperature3;}

}
