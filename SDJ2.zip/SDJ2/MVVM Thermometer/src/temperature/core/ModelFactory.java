package temperature.core;

import temperature.mediator.TemperatureModel;
import temperature.mediator.TemperatureModelManager;
import temperature.model.Temperature;

public class ModelFactory
{
  private TemperatureModelManager temperatureModelManager;

  public ModelFactory(TemperatureModelManager temperatureModelManager)
  {
    this.temperatureModelManager=temperatureModelManager;
  }

  public TemperatureModel getModel()
  {

    return temperatureModelManager;
  }
}
