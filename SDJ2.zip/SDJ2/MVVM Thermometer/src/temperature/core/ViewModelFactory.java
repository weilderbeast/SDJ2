package temperature.core;

import temperature.view.temperature.TemperatureViewModel;

public class ViewModelFactory
{
  private ModelFactory modelFactory; //<-apparently this should be here?
  private TemperatureViewModel temperatureViewModel; //<- this seems to be needed

  public ViewModelFactory(ModelFactory modelFactory)
  {
    this.modelFactory = modelFactory;
    temperatureViewModel = new TemperatureViewModel(modelFactory.getModel());
  }

  public TemperatureViewModel getTemperatureVM()
  {
    //what goes in here?
    //is this ok?

    return temperatureViewModel;
  }
}
