import javafx.application.Application;
import javafx.stage.Stage;
import temperature.core.ModelFactory;
import temperature.core.ViewModelFactory;
import temperature.external.Thermometer;
import temperature.mediator.TemperatureModel;
import temperature.mediator.TemperatureModelManager;
import temperature.core.ViewHandler;

public class MyApplication extends Application
{
  public void start(Stage primaryStage)
  {
    // This is obsolete
    TemperatureModelManager model = new TemperatureModelManager();

    //Need these to link up
    ModelFactory modelFactory = new ModelFactory(model);
    ViewModelFactory viewModelFactory = new ViewModelFactory(modelFactory); // <- this should be used in the ViewHandler

    // ViewHandler
    ViewHandler view = new ViewHandler(viewModelFactory);
    view.start(primaryStage);

    //added threads
    Thermometer t1 = new Thermometer(model,15,2,"t1");
    Thermometer t2 = new Thermometer(model,15,4,"t2");

    Thread thread1 = new Thread(t1);
    Thread thread2 = new Thread(t2);

    thread1.start();
    thread2.start();
  }
}
