import javafx.application.Application;

public class Main
{
  public static void main(String[] args) throws InterruptedException
  {
    Application.launch(MyApplication.class);
  }
}
