package foxanimation;

import javafx.application.Application;

public class RunFox {
    public static void main(String[] args) {
        Application.launch(FoxApp.class);
    }
}
