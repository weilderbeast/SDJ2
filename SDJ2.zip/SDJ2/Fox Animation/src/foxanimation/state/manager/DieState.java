package foxanimation.state.manager;

import foxanimation.FoxViewController;

public class DieState implements FoxState
{
  @Override public void Idle(FoxViewController controller)
  {
    controller.setFoxState(new IdleState());
  }

  @Override public void Walk(FoxViewController controller)
  {
    controller.setFoxState(new WalkState());
  }

  @Override public void Run(FoxViewController controller)
  {
    controller.setFoxState(new RunState());
  }

  @Override public void Attack(FoxViewController controller)
  {
    controller.setFoxState(new AttackState());
  }

  @Override public void Duck(FoxViewController controller)
  {
    controller.setFoxState(new DuckState());
  }

  @Override public void Jump(FoxViewController controller)
  {
    controller.setFoxState(new JumpState());
  }

  @Override public void Die(FoxViewController controller)
  {
    // do nothing
  }
}
