package foxanimation.state.manager;

import foxanimation.FoxViewController;

public interface FoxState
{
    void Idle(FoxViewController controller);
    void Walk(FoxViewController controller);
    void Run(FoxViewController controller);
    void Attack(FoxViewController controller);
    void Duck(FoxViewController controller);
    void Jump(FoxViewController controller);
    void Die(FoxViewController controller);
}
