public class GrillMonitor
{
  private int number_of_burgers;

  public GrillMonitor()
  {
    number_of_burgers=0;
  }

  public synchronized void createBurger()
  {
    if(number_of_burgers<20)
    {
      notify();
      number_of_burgers++;
    }
    else
    {
      try
      {
        System.out.println("The cook is now waiting.");
        wait();
      }
      catch (InterruptedException e)
      {
        e.printStackTrace();
      }
    }
  }

  public synchronized void serveBurger(int value)
  {
    if(number_of_burgers>=value)
    {
      number_of_burgers-=value;
      notify();
    }
    else{
      try
      {
        System.out.println("got HERE");
        wait();
      }
      catch (InterruptedException e)
      {
        e.printStackTrace();
      }
    }
  }

  public int getNumber_of_burgers()
  {
    return number_of_burgers;
  }
}
