import java.util.Random;

public class Customer implements Runnable
{
  private GrillMonitor grill;
  private int number;
  private int time_between_serves;
  private int number_of_burgers;

  public Customer(GrillMonitor grill,int number)
  {
    this.grill=grill;
    this.number=number;

    Random random = new Random();
    number_of_burgers = random.nextInt(3)+1;
  }

  //public boolean askForBurgers

  @Override public void run()
  {
    while(true)
    {
        if(grill.getNumber_of_burgers()>=number_of_burgers)
        {
          grill.serveBurger(number_of_burgers);

          System.out.println(
              "Customer number #" + number + " got his " + number_of_burgers +
                  " burgers.");

          Random random = new Random();
          number_of_burgers = random.nextInt(3)+1;

          try
          {
            time_between_serves = random.nextInt(1501)+2000;
            Thread.sleep(time_between_serves);
          }
          catch (InterruptedException e)
          {
            e.printStackTrace();
          }
        }
        else{
          System.out.println(
              "Customer number #" + number + " is waiting for his " + number_of_burgers +
                  " burgers.");
        }
    }
  }
}
