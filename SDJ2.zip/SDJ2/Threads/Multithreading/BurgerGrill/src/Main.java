public class Main
{
  public static void main(String[] args)
  {
    GrillMonitor grill = new GrillMonitor();

    Thread cook = new Thread(new Cook(grill));

    Thread customer1 = new Thread(new Customer(grill,1));
    Thread customer2 = new Thread(new Customer(grill,2));
    Thread customer3 = new Thread(new Customer(grill,3));

    cook.start();
    customer1.start();
    customer2.start();
    customer3.start();

    try{
      cook.join();
      customer1.join();
      customer2.join();
      customer3.join();
    }
    catch (InterruptedException e)
    {
      e.printStackTrace();
    }

  }
}
