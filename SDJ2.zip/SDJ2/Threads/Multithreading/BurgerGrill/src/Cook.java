public class Cook implements Runnable
{
  private GrillMonitor grill;
  public Cook(GrillMonitor grill)
  {
    this.grill=grill;
  }
  public void cook_burger()
  {
    grill.createBurger();
  }
  @Override public void run()
  {
    while(true)
    {
      cook_burger();
      try{
        Thread.sleep(500);
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
  }
}
