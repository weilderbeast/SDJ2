package com.company;

import java.security.Key;
import java.util.Scanner;

public class ThreadOne implements Runnable
{
  private static long TIME_TO_WAIT =1000L;
  private static int NUMBER_OF_TIMES = 10000;
  private Watch watch;

  public ThreadOne(Watch watch)
  {
    this.watch=watch;
  }

  @Override public void run()
  {
    for(int i=0;i<NUMBER_OF_TIMES;i++)
    {
      System.out.println(watch);
      watch.increment();

      try{
        Thread.sleep(TIME_TO_WAIT);
      }
      catch (InterruptedException e)
      {
        e.printStackTrace();
      }
    }
  }
}
