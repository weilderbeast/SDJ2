package com.company;

public class Main {

    public static void main(String[] args) {
        Watch watch = new Watch();

        Thread t1 = new Thread( new ThreadOne(watch));
        Thread t2 = new Thread( new ThreadTwo(watch));

        t1.start();
        t2.start();
        try{
            t1.join();
            t2.join();
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }

        //while(true) <- make JOptionPane here
        //also remember to handle exceptions when clicking cancel (teacher's problem)
    }
}
