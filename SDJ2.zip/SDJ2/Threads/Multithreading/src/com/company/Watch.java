package com.company;

import java.util.Calendar;
import java.util.Date;

public class Watch
{
  private int seconds;
  private int minutes;
  private int hours;

  public Watch()
  {
    seconds=0;
    minutes=0;
    hours=0;
  }

  public Watch(int seconds,int minutes,int hours)
  {
    this.seconds=seconds;
    this.minutes=minutes;
    this.hours=hours;
  }

  public void increment()
  {
    seconds++;
    if(seconds>60)
    {
      minutes+=seconds/60;
      seconds=0;
      if(minutes>60)
      {
        hours+=minutes/60;
        minutes=0;
      }
    }
  }

  public void increment(int number)
  {
    seconds+=number;
    if(seconds>60)
    {
      minutes+=seconds/60;
      seconds=0;
      if(minutes>60)
      {
        hours+=minutes/60;
        minutes=0;
      }
    }
  }

  public void changeTime(int seconds,int minutes,int hours)
  {
    this.seconds=seconds;
    this.minutes=minutes;
    this.hours=hours;
  }

  public String toString()
  {
    return hours+":"+minutes+":"+seconds;
  }
}
