package com.company;

import java.util.Scanner;

public class ThreadTwo implements Runnable
{
  private Watch watch;
  public ThreadTwo(Watch watch)
  {
    this.watch=watch;
  }
  @Override public void run()
  {
    //no need for this use JOptionPane bcs it will always display and will not interrupt the console
    while(true)
    {
      Scanner keyboard = new Scanner(System.in);
      System.out.println("If you wish to edit the time, press something.");
      if (keyboard.hasNextLine())
      {
        System.out.println("Enter the number of seconds you wish to add.");
        int seconds = keyboard.nextInt();
        watch.increment(seconds);
      }
    }
  }
}
