package chat.client;

public class StartChatClient
{
  public static void main(String[] args)
  {
    ChatClient cc = new ChatClient();
    cc.startClient();
  }
}
