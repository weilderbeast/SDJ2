package chat.client;

import chat.shared.Message;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;

public class ChatClient
{
  ObjectInputStream inFromServer;

  public void startClient()
  {
    try
    {
      Socket socket = new Socket("10.152.210.119", 12345);
      ObjectOutputStream outToServer = new ObjectOutputStream(socket.getOutputStream());
      inFromServer = new ObjectInputStream(socket.getInputStream());
      Scanner scanner = new Scanner(System.in);

      Thread thread = new Thread(() -> listenToServer());
      thread.setDaemon(true);
      thread.start();

      System.out.println("Insert username > ");
      String userName = scanner.nextLine();
      outToServer.writeObject(userName);

      while (true)
      {
        System.out.println("Input > ");
        String msg = scanner.nextLine();
        Message m = new Message(msg,userName);
        outToServer.writeObject(m);

        if (msg.equalsIgnoreCase("exit"))
        {
          socket.close();
          break;
        }
      }
    }
    catch (IOException e)
    {
      e.printStackTrace();
    }
  }

  private void listenToServer()
  {
    try
    {
      while (true)
      {
        Message response = (Message) inFromServer.readObject();
        System.out.println(response);
      }

    } catch (IOException | ClassNotFoundException e)
    {

    }

  }
}
