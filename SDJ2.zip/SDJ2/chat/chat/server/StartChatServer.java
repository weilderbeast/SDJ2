package chat.server;

public class StartChatServer
{
  public static void main(String[] args)
  {
    ChatServer cs = new ChatServer();
    cs.start();
  }
}
