package chat.server;

import chat.shared.Message;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ChatServerHandler implements Runnable
{

  private Socket socket;
  private ObjectInputStream inFromClient;
  private ObjectOutputStream outToClient;
  private ConnectionPool pool;
  private String userName;

  public ChatServerHandler(Socket socket, ConnectionPool pool)
  {
    this.socket = socket;
    this.pool = pool;
    try
    {
      inFromClient = new ObjectInputStream(socket.getInputStream());
      outToClient = new ObjectOutputStream(socket.getOutputStream());
    }
    catch (IOException e)
    {
      e.printStackTrace();
    }
  }

  @Override public void run()
  {
    try
    {
      userName = (String) inFromClient.readObject();
      while (true)
      {
        Message message = (Message) inFromClient.readObject();

        String body = message.getMessageBody();
        System.out.println(message);

        if (body.equalsIgnoreCase("exit")) {
          pool.removeConnection(this);
          socket.close();
          break;
        }

        pool.broadcast(message);
      }
    }
    catch (IOException e)
    {
      e.printStackTrace();
    }
    catch (ClassNotFoundException e)
    {
      e.printStackTrace();
    }
  }

  public void sendMessageToClient(Message msg)
  {
    try
    {
      outToClient.writeObject(msg);
    }
    catch (IOException e)
    {
      e.printStackTrace();
    }
  }

  public String getClientName()
  {
    return userName;
  }
}
