package temperature.view;

public interface Listener
{
  void update(Object arg);
}
