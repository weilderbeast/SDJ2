package temperature.mediator;

import temperature.view.Listener;

public interface Subject
{
  void addListener(Listener lstnr);
  void removeListener(Listener lstnr);
}
