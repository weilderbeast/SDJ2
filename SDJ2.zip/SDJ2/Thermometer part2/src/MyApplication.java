import javafx.application.Application;
import javafx.stage.Stage;
import temperature.core.Thermometer;
import temperature.mediator.TemperatureModel;
import temperature.mediator.TemperatureModelManager;
import temperature.view.ViewHandler;

public class MyApplication extends Application
{
  public void start(Stage primaryStage)
  {
    // Model
    TemperatureModel model = new TemperatureModelManager();

    // View
    ViewHandler view = new ViewHandler(model);
    view.start(primaryStage);

    // Threads
    Thermometer t1 = new Thermometer(model,15,2,"t1");
    Thermometer t2 = new Thermometer(model,15,5,"t2");

    Thread thermometer1 = new Thread(t1);
    Thread thermometer2 = new Thread(t2);

    //need to add here a listener but what?

    thermometer1.start();
    thermometer2.start();
    //do not join the threads, the program doesn't like that
  }
}
