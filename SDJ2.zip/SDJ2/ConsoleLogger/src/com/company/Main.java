package com.company;

import java.io.FileWriter;
import java.io.IOException;

public class Main {

    public static void main(String[] args) {
        Log log = new LoggerProxy("sparse");
        log.log("error on line 28");
        log.log("nothing to see here");
        try {
            FileWriter writer = new FileWriter("src/text.txt");
            writer.write("tvccr");
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
