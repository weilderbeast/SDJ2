package com.company;

public class LoggerProxy implements Log{

    private enum log_level{ SPARSE, VERBOSE};
    private log_level privilege = log_level.SPARSE;
    private final static Logger logger = new Logger();

    public LoggerProxy(String privilege){
        if(privilege.equalsIgnoreCase(log_level.SPARSE.toString())){
            this.privilege = log_level.SPARSE;
        } else if(privilege.equalsIgnoreCase(log_level.VERBOSE.toString())){
            this.privilege = log_level.VERBOSE;
        }
    }

    @Override
    public void log(String txt) {
        if(privilege.equals(log_level.SPARSE)){
            if(txt.contains("error")){
                logger.log(txt);
            }
        } else {
            logger.log(txt);
        }
    }
}
