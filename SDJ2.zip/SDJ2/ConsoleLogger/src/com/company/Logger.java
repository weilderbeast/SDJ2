package com.company;

public class Logger implements Log{
    public Logger(){

    }

    @Override
    public void log(String txt){
        System.out.println(txt);
    }
}
