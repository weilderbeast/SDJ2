package com.company;

public interface Log {
    void log(String txt);
}
