/*
 * 27.10.2019 Original version
 */


package dk.via.jpe.prodconscq;

public interface Buffer<T>
{
	public void put( T value );
	
	public T take();
}
