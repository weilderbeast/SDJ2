/*
 * 27.10.2019 Original version
 */


package dk.via.jpe.prodconscq;

public class CircularArrayQueue<T>
	implements Buffer<T>
{
	private T[] elements;
	private int size;
	private int head = 0;
	private int tail = 0;
	private int count = 0;
	
	
	public CircularArrayQueue( int size )
	{
		this.size = size;
		elements = (T[]) new Object[size];
	}
	
	@Override
	public void put( T value )
	{
		while( count == size )
			Thread.yield();
		
		elements[tail] = value;
		tail = ( tail + 1 ) % size;
		++count;
	}
	
	@Override
	public T take()
	{
		while( count == 0 )
			Thread.yield();

		T result = elements[head];
		head = ( head + 1 ) % size;
		count--;
		
		return result;
	}
}
