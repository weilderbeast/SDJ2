# ChatSystem
Chat system built in java for an university assignment
Done using sockets and the MVVM and Observer design patterns.
