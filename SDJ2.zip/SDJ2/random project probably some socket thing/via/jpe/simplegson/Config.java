/*
 * 11.09.2019 Original version
 */


package via.jpe.simplegson;


public class Config
{
	public static final int PORT = 54321;
	
	public static final int UPPER_ACTION = 1;
	public static final int LOWER_ACTION = 2;
}
