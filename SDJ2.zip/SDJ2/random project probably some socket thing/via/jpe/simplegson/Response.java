/*
 * 11.09.2019 Original version
 */


package via.jpe.simplegson;


public class Response
{
	private String text;
	
	
	public Response( String text )
	{
		this.text = text;
	}
	
	
	public String getText()
	{
		return text;
	}
}
