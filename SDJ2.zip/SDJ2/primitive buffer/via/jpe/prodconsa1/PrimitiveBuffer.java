/*
 * 27.10.2019 Original version
 */


package via.jpe.prodconsa1;


public class PrimitiveBuffer<T>
	implements Buffer<T>
{
	private T value;
	private boolean ready = false;
	
	
	@Override
	public synchronized void put( T value )
	{
		if(value != null) {
			notify();
		}
		else{
			try {
				wait();
			} catch (InterruptedException e) {
				System.out.println("exception");
			}
		}
		this.value = value;
	}
	
	@Override
	public synchronized T take()
	{
		if(value != null){
			notifyAll();
		}
		else{
			try {
				wait();
			} catch (InterruptedException e) {
				System.out.println("exception");
			}
		}
		return value;
	}
}
