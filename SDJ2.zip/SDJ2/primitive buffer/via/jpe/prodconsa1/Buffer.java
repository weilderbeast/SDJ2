/*
 * 27.10.2019 Original version
 */


package via.jpe.prodconsa1;

public interface Buffer<T>
{
	public void put( T value );
	
	public T take();
}
