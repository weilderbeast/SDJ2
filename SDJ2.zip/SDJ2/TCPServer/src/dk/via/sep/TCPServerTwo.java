package dk.via.sep;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

import static dk.via.sep.TCPServerConfig.PORTNO;

public class TCPServerTwo
{
  public static void main(String[] args)
  {
    new TCPServerTwo().run();
  }

  private void run()
  {
    try{
      ServerSocket welcomeSocket = new ServerSocket( PORTNO );
      System.out.println("Listening  on " + InetAddress.getLocalHost().getHostAddress());

      while(true){
        Socket clientSocket = welcomeSocket.accept();
        doWork(clientSocket);
      }
    } catch (Exception e){}
  }

  private void doWork( Socket clientSocket)
      throws IOException, InterruptedException
  {
    BufferedReader in = new BufferedReader(
        new InputStreamReader( clientSocket.getInputStream() ) );
    OutputStreamWriter out =
        new OutputStreamWriter( clientSocket.getOutputStream() );

    out.write("Select between check and reverse");
//    String input = in.readLine();
//    System.out.println("Received: " + input);
//
//
//    String output = "";
//    System.out.println("Sent: " + output);
//
//    out.write(output);
//    out.flush();

    clientSocket.close();
  }
}
