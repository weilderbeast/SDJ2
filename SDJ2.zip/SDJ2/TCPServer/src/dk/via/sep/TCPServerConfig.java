package dk.via.sep;

public class TCPServerConfig
{
  public static final int PORTNO = 6969;
}
